//asddzdcs 
// asdkasjdasjdja
//
#include<stdio.h>

int main()
{
    //vxcvxv
    int k = 1;
    printf("k");
    return 0;
    //fsfadf
    //fsfadf
}

void main(){};
/*fggdgdg
dfggdgdfg*/

