#include <stdio.h>
int main()
{
//sai ruthik
/*ghsdfghgfhdg
hjfgdfhkdhg*/
}