


#include<stdio.h>

int main()
{
    
    int k = 1;
    printf("k");
    return 0;
    
    
}

void main(){};


