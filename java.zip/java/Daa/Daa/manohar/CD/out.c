
void main(){
   
  printf("welcome");
  
}
