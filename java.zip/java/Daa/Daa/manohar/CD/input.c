/* program to print welcome message */
void main(){
   //declaration
  printf("welcome");
  //end
}
