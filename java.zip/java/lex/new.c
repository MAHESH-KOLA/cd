writef("hello");
readf("%d",&n);
writef("hello");
readf("%d",&n);
