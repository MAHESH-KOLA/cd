printf("hello");
scanf("%d",&n);
printf("hello");
scanf("%d",&n);
